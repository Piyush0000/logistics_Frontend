# @logicore/contracts

The source of truth for every shape that crosses a service boundary. zod schemas with inferred
TypeScript types. No runtime dependencies other than zod.

| File          | Defines                                                                         |
| ------------- | ------------------------------------------------------------------------------- |
| `shipment.ts` | `StandardShipmentRequest` (addresses, pincodes, weight, dimensions, items, COD) |
| `status.ts`   | `NormalizedStatus` (the only statuses the platform understands)                 |
| `topics.ts`   | `TOPICS` constants and `dlqTopic()`                                             |
| `events.ts`   | Event payload schemas per topic, `EVENT_SCHEMAS`, `DeadLetterRecord`            |
| `adapter.ts`  | `CarrierAdapter` interface and its input/output schemas                         |
| `carriers.ts` | `CARRIERS` / `CarrierName` (`make new-adapter` appends here)                    |
| `fixtures.ts` | `sampleShipmentRequest()`, the shared valid request for tests and smoke runs    |

Changing this package affects every service. Read "Changing contracts" in
[CONTRIBUTING.md](../../CONTRIBUTING.md) first.
